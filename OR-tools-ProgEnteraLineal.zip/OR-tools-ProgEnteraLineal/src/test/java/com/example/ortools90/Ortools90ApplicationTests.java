package com.example.ortools90;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ortools90ApplicationTests {

	@Test
	void contextLoads() {
	}

}
